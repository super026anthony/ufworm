import pyxel
import enum
import time
import random
import collections

class Direction(enum.Enum):
    RIGHT = 0
    DOWN = 1
    LEFT = 2
    UP = 3

class GameState(enum.Enum):
    RUNNING = 0
    GAME_OVER_PRESS_R = 1

class Worm:
    def __init__(self, x, y, is_head = False):
        self.x = x
        self.y = y
        self.w = 8
        self.h = 8
        self.is_head = is_head

    def draw(self, direction):
        width = self.w
        height = self.h
        sprite_x = 0
        sprite_y = 0
        if self.is_head:
            if direction == direction.RIGHT:
                sprite_x = 8
                sprite_y = 0
            if direction == direction.LEFT:
                sprite_x = 8
                sprite_y = 0
                width *= -1
            if direction == direction.UP:
                sprite_x = 0
                sprite_y = 8
                height *= -1
            if direction == direction.DOWN:
                sprite_x = 0
                sprite_y = 8    
        pyxel.blt(self.x, self.y, 0, sprite_x, sprite_y, width, height)

    def intersects(self, u, v, w, h):
        is_interesected = False
        if (
            u + w > self.x
            and self.x + self.w > u
            and v + h > self.y
            and self.y + self.h > v
        ):
            is_interesected = True
        return is_interesected

class Lava:
    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.w = 8
        self.h = 8

    def draw(self):
        pyxel.blt(self.x, self.y, 0, 32, 0, self.w, self.h)

    def intersects(self, u, v, w, h):
        is_interesected = False
        if (
            u + w > self.x
            and self.x + self.w > u
            and v + h > self.w
            and self.y + self.h > v
        ):
            is_interesected = True
        return is_interesected

    def move(self, new_x, new_y):
        self.x = new_x
        self.y = new_y

class Banana:
    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.w = 8
        self.h = 8

    def draw(self):
        pyxel.blt(self.x, self.y, 0, 16, 0, self.w, self.h)

    def intersects(self, u, v, w, h):
        is_interesected = False
        if (
            u + w > self.x
            and self.x + self.w > u
            and v + h > self.w
            and self.y + self.h > v
        ):
            is_interesected = True
        return is_interesected

    def move(self, new_x, new_y):
        self.x = new_x
        self.y = new_y

class App:
    def __init__(self):
        self.score = 2
        pyxel.init(240, 240, title = "GAME WINDOW", fps = 60)
        pyxel.load('[PYXEL_RESOURCE_FILE].pyxres')
        self.current_game_state = GameState.RUNNING
        self.randX = random.randrange(8, 232, 8)
        self.randY = random.randrange(8, 232, 8)
        self.banana = Banana(self.randX, self.randY)
        self.randX = random.randrange(8, 232, 8)
        self.randY = random.randrange(8, 232, 8)
        self.lava = Lava(self.randX, self.randY)
        self.worm = []
        self.randX = random.randrange(24, 232, 8)
        self.randY = random.randrange(24, 232, 8)
        self.worm.append(Worm(self.randX, self.randY, is_head = True))
        self.worm.append(Worm(self.randX - 8, self.randY))
        self.worm.append(Worm(self.randX - 16, self.randY))
        self.worm_direction: Direction = Direction.RIGHT
        self.sections_to_add = 0
        self.speed = 1.5
        self.time_last_frame = time.time()
        self.dt = 0
        self.time_since_last_move = 0
        self.input_queue = collections.deque()
        pyxel.run(self.update, self.draw)

    def start_new_game(self):
        self.current_game_state = GameState.RUNNING
        self.score = 2
        self.randX = random.randrange(8, 232, 8)
        self.randY = random.randrange(8, 232, 8)
        self.banana = Banana(self.randX, self.randY)
        self.randX = random.randrange(8, 232, 8)
        self.randY = random.randrange(8, 232, 8)
        self.lava = Lava(self.randX, self.randY)
        self.worm.clear()
        self.randX = random.randrange(24, 232, 8)
        self.randY = random.randrange(24, 232, 8)
        self.worm.append(Worm(self.randX, self.randY, is_head = True))
        self.worm.append(Worm(self.randX - 8, self.randY))
        self.worm.append(Worm(self.randX - 16, self.randY))
        self.worm_direction: Direction = Direction.RIGHT
        self.sections_to_add = 0
        self.speed = 1.5
        self.time_last_frame = time.time()
        self.dt = 0
        self.time_since_last_move = 0
        self.input_queue.clear()
        self.move_banana()
        pyxel.play_pos(0)

    def update(self):
        time_this_frame = time.time()
        self.dt = time_this_frame - self.time_last_frame
        self.time_last_frame = time_this_frame
        self.time_since_last_move += self.dt
        self.check_input()
        if self.current_game_state == GameState.RUNNING:
            if self.time_since_last_move >= 1 / self.speed:
                self.time_since_last_move = 0
                self.move_worm()
                self.check_collisions()

    def draw(self):
        pyxel.cls(0)
        self.banana.draw()
        self.lava.draw()
        for s in self.worm:
            s.draw(self.worm_direction)
        pyxel.text(8, 224, str(self.score), 12)
        pyxel.text(8, 232, str(self.current_game_state), 9)
    
    def check_collisions(self):
        if self.banana.intersects(self.worm[0].x, self.worm[0].y, self.worm[0].w, self.worm[0].h):
            self.score += 1
            self.speed += (self.speed * 0.1)
            self.sections_to_add += 1
            self.move_banana()
        if self.lava.intersects(self.worm[0].x, self.worm[0].y, self.worm[0].w, self.worm[0].h):
            self.current_game_state = GameState.GAME_OVER_PRESS_R
        for s in self.worm:
            if s == self.worm[0]:
                continue
            if s.intersects(self.worm[0].x, self.worm[0].y, self.worm[0].w, self.worm[0].h):
                self.current_game_state = GameState.GAME_OVER_PRESS_R
    
    def move_banana(self):
        good_position = False
        while not good_position:
            new_x = random.randrange(32, 232, 8)
            new_y = random.randrange(32, 232, 8)
            good_position = True
            for s in self.worm:
                if (
                    new_x + 8 > s.y
                    and s.x + s.w > new_x
                    and new_y + 8 > s.y
                    and s.y + s.h > new_y
                ):
                    good_position = False
                    break
            if good_position:
                self.banana.move(new_x, new_y)

    def move_lava(self):
        good_position = False
        while not good_position:
            new_x = random.randrange(32, 232, 8)
            new_y = random.randrange(32, 232, 8)
            good_position = True
            for s in self.worm:
                if (
                    new_x + 8 > s.y
                    and s.x + s.w > new_x
                    and new_y + 8 > s.y
                    and s.y + s.h > new_y
                ):
                    good_position = False
                    break
            if good_position:
                self.lava.move(new_x, new_y)

    def move_worm(self):
        if len(self.input_queue):
            self.worm_direction = self.input_queue.popleft()
        if self.sections_to_add > 0:
            self.worm.append(Worm(self.worm[-1].x, self.worm[-1].y))
            self.sections_to_add -= 1
        previous_location_x = self.worm[0].x
        previous_location_y = self.worm[0].y
        if self.worm_direction == Direction.RIGHT:
            self.worm[0].x += self.worm[0].w
        if self.worm_direction == Direction.LEFT:
            self.worm[0].x -= self.worm[0].w
        if self.worm_direction == Direction.UP:
            self.worm[0].y -= self.worm[0].w
        if self.worm_direction == Direction.DOWN:
            self.worm[0].y += self.worm[0].w
        for s in self.worm:
            if s == self.worm[0]:
                continue
            current_location_x = s.x
            current_location_y = s.y
            s.x = previous_location_x
            s.y = previous_location_y
            previous_location_x = current_location_x
            previous_location_y = current_location_y

    def check_input(self):
        if self.current_game_state == GameState.GAME_OVER_PRESS_R:
            if pyxel.btn(pyxel.KEY_R):
                self.start_new_game()
        if pyxel.btn(pyxel.KEY_RIGHT):
            if len(self.input_queue) == 0:
                if self.worm_direction != Direction.LEFT and self.worm_direction != Direction.RIGHT:
                    self.input_queue.append(Direction.RIGHT)
            else:
                if self.input_queue[-1] != Direction.LEFT and self.input_queue[-1] != Direction.RIGHT:
                    self.input_queue.append(Direction.RIGHT)
        
        if pyxel.btn(pyxel.KEY_LEFT):
            if len(self.input_queue) == 0:
                if self.worm_direction != Direction.RIGHT and self.worm_direction != Direction.LEFT:
                    self.input_queue.append(Direction.LEFT)
            else:
                if self.input_queue[-1] != Direction.RIGHT and self.input_queue[-1] != Direction.LEFT:
                    self.input_queue.append(Direction.LEFT)

        if pyxel.btn(pyxel.KEY_UP):
            if len(self.input_queue) == 0:
                if self.worm_direction != Direction.DOWN and self.worm_direction != Direction.UP:
                    self.input_queue.append(Direction.UP)
            else:
                if self.input_queue[-1] != Direction.DOWN and self.input_queue[-1] != Direction.UP:
                    self.input_queue.append(Direction.UP)
        
        if pyxel.btn(pyxel.KEY_DOWN):
            if len(self.input_queue) == 0:
                if self.worm_direction != Direction.UP and self.worm_direction != Direction.DOWN:
                    self.input_queue.append(Direction.DOWN)
            else:
                if self.input_queue[-1] != Direction.UP and self.input_queue[-1] != Direction.DOWN:
                    self.input_queue.append(Direction.DOWN)        
    
    

App()